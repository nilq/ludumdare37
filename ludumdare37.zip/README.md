# ludumdare37
"a game about game stuff" - Nilq, 00:14:22 Dec 10, 2016

TODO
---

- Implement world
- Implement player
- Implement computer
  - language
  - filesystem/terminal stuff
- Coffee

### Computer ...

Idea shit
---

- Farmer

  Herd, feed and protect sheep
